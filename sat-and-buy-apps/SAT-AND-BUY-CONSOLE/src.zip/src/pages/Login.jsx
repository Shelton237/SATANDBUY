import React from "react";
import { Link } from "react-router-dom";
import { Button, Select } from "@windmill/react-ui";
import { useTranslation } from "react-i18next";

// Components
import Error from "@/components/form/others/Error";
import LabelArea from "@/components/form/selectOption/LabelArea";
import InputArea from "@/components/form/input/InputArea";
import CMButton from "@/components/form/button/CMButton";

// Assets
import ImageLight from "@/assets/img/login-office.jpeg";
import ImageDark from "@/assets/img/login-office-dark.jpeg";

// Hooks
import useLoginSubmit from "@/hooks/useLoginSubmit";

const languageOptions = [
  { value: "en", label: "English" },
  { value: "fr", label: "Français" }, // Correction: 'fr' au lieu de 'de' pour le français
];

const Login = () => {
  const { t, i18n } = useTranslation();
  const { onSubmit, register, handleSubmit, errors, loading } = useLoginSubmit();

  const handleLanguageChange = (e) => {
    const language = e.target.value;
    i18n.changeLanguage(language)
      .then(() => {
        console.log("Langue changée avec succès:", language);
      })
      .catch(err => {
        console.error("Erreur changement de langue:", err);
      });
  };

  return (
    <div className="flex items-center min-h-screen p-6 bg-gray-50 dark:bg-gray-900">
      <div className="flex-1 h-full max-w-4xl mx-auto overflow-hidden bg-white rounded-lg shadow-xl dark:bg-gray-800">
        <div className="flex flex-col md:flex-row">
          <div className="h-32 md:h-auto md:w-1/2">
            <img
              aria-hidden="true"
              className="object-cover w-full h-full dark:hidden"
              src={ImageLight}
              alt="Office"
              loading="lazy"
              decoding="async" // Ajout pour la performance
            />
            <img
              aria-hidden="true"
              className="hidden object-cover w-full h-full dark:block"
              src={ImageDark}
              alt="Office"
              loading="lazy"
              decoding="async" // Ajout pour la performance
            />
          </div>
          
          <main className="flex items-center justify-center p-6 sm:p-12 md:w-1/2">
            <div className="w-full">
              <div className="flex justify-between items-start mb-6">
                <h1 className="text-2xl font-semibold text-gray-700 dark:text-gray-200">
                  {t("LoginTitle")}
                </h1>
                <Select
                  className="w-32 text-sm"
                  onChange={handleLanguageChange}
                  value={i18n.language || "en"} // Valeur par défaut
                >
                  {languageOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </Select>
              </div>
              
              <form onSubmit={handleSubmit(onSubmit)} noValidate> {/* Ajout de noValidate */}
                <LabelArea label={t("Email")} />
                <InputArea
                  required
                  register={register}
                  label="Email"
                  name="email"
                  type="email"
                  autoComplete="username"
                  placeholder="john@doe.com"
                  error={errors.email} // Passage de l'erreur directement
                />
                
                <div className="mt-6">
                  <LabelArea label={t("Password")} />
                  <InputArea
                    required
                    register={register}
                    label="Password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    placeholder="***************"
                    error={errors.password} // Passage de l'erreur directement
                  />
                </div>

                <div className="mt-4">
                  {loading ? (
                    <CMButton
                      disabled
                      type="submit"
                      className="bg-emerald-600 rounded-md h-12 w-full"
                    />
                  ) : (
                    <Button
                      type="submit"
                      className="h-12 w-full"
                    >
                      {t("LoginTitle")}
                    </Button>
                  )}
                </div>
              </form>

              <p className="mt-4 text-center">
                <Link
                  className="text-sm font-medium text-emerald-500 dark:text-emerald-400 hover:underline focus:outline-none focus:ring-2 focus:ring-emerald-400" // Amélioration accessibilité
                  to="/forgot-password"
                >
                  {t("ForgotPassword")}
                </Link>
              </p>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};

export default React.memo(Login);