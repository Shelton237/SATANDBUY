import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Scrollbars } from "react-custom-scrollbars-2";
import { Card, CardBody, Input } from "@windmill/react-ui";
import { useTranslation } from "react-i18next";

import Error from "@/components/form/others/Error";
import Title from "@/components/form/others/Title";
import InputArea from "@/components/form/input/InputArea";
import useStaffSubmit from "@/hooks/useStaffSubmit";
import SelectRole from "@/components/form/selectOption/SelectRole";
import DrawerButton from "@/components/form/button/DrawerButton";
import LabelArea from "@/components/form/selectOption/LabelArea";
import Uploader from "@/components/image-uploader/Uploader";

const StaffDrawer = ({ roles: propsRoles = [] }) => {
  const [roles, setRoles] = useState(propsRoles);
  const { t } = useTranslation();
  
  const {
    register,
    handleSubmit,
    onSubmit,
    errors,
    imageUrl,
    setImageUrl,
    isSubmitting,
    selectedDate,
    setSelectedDate,
    language,
    setLanguage,
    resData,
  } = useStaffSubmit();

  // Synchronisation des rôles lorsque les props changent
  useEffect(() => {
    if (JSON.stringify(roles) !== JSON.stringify(propsRoles)) {
      setRoles(propsRoles);
      console.log("Mise à jour des rôles:", {
        ancien: roles.slice(0, 3),
        nouveau: propsRoles.slice(0, 3)
      });
    }
  }, [propsRoles]);

  // Filtrage des rôles
  const roleOptions = useMemo(() => {
    const SYSTEM_ROLES = [
      'offline_access',
      'uma_authorization',
      'default-roles-master',
      'create-realm'
    ];

    return roles
      .filter(role => {
        const isValid = role?.name;
        if (!isValid) console.warn("Role invalide filtré:", role);
        return isValid;
      })
      .filter(role => !SYSTEM_ROLES.includes(role.name))
      .map(role => ({
        value: role.name,
        label: role.description || role.name,
        original: role
      }));
  }, [roles]);

  const defaultRoleValue = useMemo(() => {
    if (!resData?.roles?.[0]) return '';
    
    const userRole = resData.roles[0];
    const roleName = typeof userRole === 'string' ? userRole : userRole.name;
    
    return roleOptions.some(opt => opt.value === roleName) ? roleName : '';
  }, [resData?.roles, roleOptions]);

  const isUpdate = !!resData?.id;

  const formFields = useMemo(() => [
    {
      label: t("Username"),
      name: "username",
      type: "text",
      required: true,
      placeholder: t("UsernamePlaceholder"),
      defaultValue: resData?.username || ""
    },
    {
      label: t("FirstName"),
      name: "firstName",
      type: "text",
      required: true,
      placeholder: t("FirstNamePlaceholder"),
      defaultValue: resData?.firstName || ""
    },
    {
      label: t("LastName"),
      name: "lastName",
      type: "text",
      required: true,
      placeholder: t("LastNamePlaceholder"),
      defaultValue: resData?.lastName || ""
    },
    {
      label: t("Email"),
      name: "email",
      type: "email",
      required: true,
      placeholder: t("EmailPlaceholder"),
      defaultValue: resData?.email || ""
    },
    {
      label: t("Password"),
      name: "password",
      type: "password",
      required: !isUpdate,
      placeholder: t("PasswordPlaceholder")
    },
    {
      label: t("Phone"),
      name: "phone",
      type: "text",
      required: false,
      placeholder: t("PhonePlaceholder"),
      pattern: /^[+]?[0-9]*$/,
      defaultValue: resData?.phone || ""
    }
  ], [t, resData, isUpdate]);

  const handleSelectLanguage = useCallback((lang) => {
    setLanguage(lang);
  }, [setLanguage]);

  return (
    <>
      <div className="w-full relative p-6 border-b border-gray-100 bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300">
        <Title
          register={register}
          handleSelectLanguage={handleSelectLanguage}
          title={isUpdate ? t("UpdateStaff") : t("AddStaffTitle")}
          description={isUpdate ? t("UpdateStaffdescription") : t("AddStaffdescription")}
          currentLanguage={language}
        />
      </div>

      <Scrollbars className="w-full md:w-7/12 lg:w-8/12 xl:w-8/12 relative dark:bg-gray-700 dark:text-gray-200">
        <Card className="overflow-y-scroll flex-grow scrollbar-hide w-full max-h-full">
          <CardBody>
            <form onSubmit={handleSubmit((data) => onSubmit(data, roles))}>
              <div className="px-6 pt-8 flex-grow scrollbar-hide w-full max-h-full pb-40">
                <div className="text-xs p-2 mb-4 bg-gray-100 dark:bg-gray-700 rounded">
                  <p>Rôles disponibles: {roleOptions.length}/{roles.length}</p>
                  <p>Mode: {isUpdate ? 'Mise à jour' : 'Création'}</p>
                </div>

                <div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
                  <LabelArea label={t("StaffImage")} />
                  <div className="col-span-8 sm:col-span-4">
                    <Uploader 
                      imageUrl={imageUrl} 
                      setImageUrl={setImageUrl} 
                      folder="admin" 
                    />
                  </div>
                </div>

                {formFields.map((field) => (
                  <div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6" key={field.name}>
                    <LabelArea label={field.label} />
                    <div className="col-span-8 sm:col-span-4">
                      <InputArea 
                        register={register} 
                        errors={errors}
                        {...field} 
                      />
                      <Error errorName={errors[field.name]} />
                    </div>
                  </div>
                ))}

                <div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
                  <LabelArea label={t("JoiningDate")} />
                  <div className="col-span-8 sm:col-span-4">
                    <Input
                      onChange={(e) => setSelectedDate(e.target.value)}
                      name="joiningDate"
                      value={selectedDate}
                      type="date"
                      placeholder={t("StaffJoiningDate")}
                    />
                    <Error errorName={errors.joiningDate} />
                  </div>
                </div>

                <div className="grid grid-cols-6 gap-3 md:gap-5 xl:gap-6 lg:gap-6 mb-6">
                  <LabelArea label={t("StaffRole")} />
                  <div className="col-span-8 sm:col-span-4">
                    {roleOptions.length > 0 ? (
                      <SelectRole 
                        register={register} 
                        label={t("Role")} 
                        name="role" 
                        defaultValue={defaultRoleValue}
                        options={roleOptions}
                      />
                    ) : (
                      <div className="text-sm text-red-500 p-2 bg-red-50 rounded">
                        <p>Aucun rôle valide disponible</p>
                        <p className="text-xs mt-1">
                          {roles.length === 0 
                            ? "Le tableau de rôles est vide"
                            : `${roles.length} rôles filtrés à 0`}
                        </p>
                      </div>
                    )}
                    <Error errorName={errors.role} />
                  </div>
                </div>
              </div>

              <DrawerButton 
                isUpdate={isUpdate}
                title="Staff" 
                isSubmitting={isSubmitting} 
              />
            </form>
          </CardBody>
        </Card>
      </Scrollbars>
    </>
  );
};

export default React.memo(StaffDrawer);