// /context/AdminContext.js
import Cookies from 'js-cookie';
import React, { createContext, useReducer } from 'react';
import AuthService from '@/services/AuthService';

export const AdminContext = createContext();

const initialState = {
  adminInfo: Cookies.get('adminInfo')
    ? JSON.parse(Cookies.get('adminInfo'))
    : null,
};

function reducer(state, action) {
  switch (action.type) {
    case 'USER_LOGIN':
      return { ...state, adminInfo: action.payload };
    case 'USER_LOGOUT':
      return { ...state, adminInfo: null };
    default:
      return state;
  }
}

export const AdminProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const customDispatch = async (action) => {
    if (action.type === 'USER_LOGOUT') {
      await AuthService.logout(); // ← logout Keycloak + clear cookie
    }
    dispatch(action);
  };

  return (
    <AdminContext.Provider value={{ state, dispatch: customDispatch }}>
      {children}
    </AdminContext.Provider>
  );
};
